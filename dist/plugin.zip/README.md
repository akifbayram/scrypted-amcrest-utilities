# Amcrest Utilities

Utilities for Amcrest and Dahua cameras:
- Set OSD texts dynamically from Scrypted

# Acknowledgments

[https://github.com/apocaliss92/scrypted-hikvision-utilities](https://github.com/apocaliss92/scrypted-hikvision-utilities)